# helloworld.pycode
import utime


def prtHelloworld():
    while True:
        print("hello world")
        utime.sleep(1)
