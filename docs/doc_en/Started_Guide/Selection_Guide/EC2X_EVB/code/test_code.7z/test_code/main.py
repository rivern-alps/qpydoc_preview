# main.py：
# Call helloworld.py file
from usr import helloworld
# Call the prtHelloworld() in helloworld.py file
helloworld.prtHelloworld()
