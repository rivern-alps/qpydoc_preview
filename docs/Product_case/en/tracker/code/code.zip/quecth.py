from usr import QuecThing
import modem
from umqtt import MQTTClient

def sub_cb(topic, msg):
    # global state
    print("Subscribe Recv: Topic={},Msg={}".format(topic.decode(), msg.decode()))
    
    
def run(productKey, productSecret, rand, imei):
    # 注册设备并返回认证密钥
    data = QuecThing.register(productKey, productSecret, rand, imei)
    print(data)
    if data.get("RESPCODE") != 10200:
        print("register failed ")
        return

    deviceSecret = data.get("DS")
    mqttServer = data.get("SERVERURI")

    clientid = "{imei}_1".format(imei=imei)
    host, port = mqttServer.split("//")[1].split(":")
    c = MQTTClient(clientid, host, int(port), clientid, deviceSecret)
    c.set_callback(sub_cb)
    c.connect()

    sub_topic = "quec/{imei}/down".format(imei=imei)
    pub_topic = "quec/{imei}/up".format(imei=imei)
    c.subscribe(sub_topic)


if __name__ == '__main__':

    productKey = "K3I5ZkgyZjkydGli"
    # 平台创建产品通过邮件发送的产品密钥
    productSecret = "VUFyVE92YVJmSUNQ"
    # 32位随机值
    rand = "q9f5UdAlh687grFl0JVuyY6295406ehd"
    # 获取模块imei号
    imei = "868540050028299"
    run(productKey, productSecret, rand, imei)