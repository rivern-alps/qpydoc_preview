# -*- coding: UTF-8 -*-
import log
from machine import LCD
from usr import fonts

# Screen parameters
screen_high = 240       # Screen height
screen_wide = 240       # Screen height
XSTART_H = 0xf0  		# Start point X coordinate high byte register
XSTART_L = 0xf1  		# Start point X coordinate low byte register
XEND_H = 0xE0  			# End point X coordinate high byte register
XEND_L = 0xE1  			# End point X coordinate low byte register
YSTART_H = 0xf2  		# Start point y coordinate high byte register
YSTART_L = 0xf3  		# Start point y coordinate low byte register
YEND_H = 0xE2  			# End point y coordinate high byte register
YEND_L = 0xE3  			# End point y coordinate low byte register

XSTART = 0xD0
XEND = 0xD1
YSTART = 0xD2
YEND = 0xD3


class ST7789V(object):
    def __init__(self, width, hight):
        self.lcdlog = log.basicConfig()
        self.lcdlog = log.getLogger("LCD")
        self.lcdlog.setLevel(log.DEBUG)
        self.lcd = LCD()
        self.lcd_w = width
        self.lcd_h = hight

        # Screen initialization parameters
        # Three elements in a tuple form a group, and each element in a single group is defined as follows:
        # 1: Type, 0 indicates command; 1 represents data; 2 indicates delay
        # 2: Length. If the type is 0, the length represents the amount of data after the command; If the type is 1, the length represents the length of the data
        # 3: Parameter value
        self.st7789v_init_data = (
            2, 1, 120,
            0, 0, 0x11,
            2, 1, 120,
            0, 1, 0x36,
            1, 1, 0x00,
            0, 1, 0x3A,
            1, 1, 0x05,
            0, 0, 0x21,
            0, 5, 0xB2,
            1, 1, 0x05,
            1, 1, 0x05,
            1, 1, 0x00,
            1, 1, 0x33,
            1, 1, 0x33,
            0, 1, 0xB7,
            1, 1, 0x23,
            0, 1, 0xBB,
            1, 1, 0x22,
            0, 1, 0xC0,
            1, 1, 0x2C,
            0, 1, 0xC2,
            1, 1, 0x01,
            0, 1, 0xC3,
            1, 1, 0x13,
            0, 1, 0xC4,
            1, 1, 0x20,
            0, 1, 0xC6,
            1, 1, 0x0F,
            0, 2, 0xD0,
            1, 1, 0xA4,
            1, 1, 0xA1,
            0, 1, 0xD6,
            1, 1, 0xA1,
            0, 14, 0xE0,
            1, 1, 0x70,
            1, 1, 0x06,
            1, 1, 0x0C,
            1, 1, 0x08,
            1, 1, 0x09,
            1, 1, 0x27,
            1, 1, 0x2E,
            1, 1, 0x34,
            1, 1, 0x46,
            1, 1, 0x37,
            1, 1, 0x13,
            1, 1, 0x13,
            1, 1, 0x25,
            1, 1, 0x2A,
            0, 14, 0xE1,
            1, 1, 0x70,
            1, 1, 0x04,
            1, 1, 0x08,
            1, 1, 0x09,
            1, 1, 0x07,
            1, 1, 0x03,
            1, 1, 0x2C,
            1, 1, 0x42,
            1, 1, 0x42,
            1, 1, 0x38,
            1, 1, 0x14,
            1, 1, 0x14,
            1, 1, 0x27,
            1, 1, 0x2C,
            0, 0, 0x29,

            0, 1, 0x36,
            1, 1, 0x00,

            0, 4, 0x2a,
            1, 1, 0x00,
            1, 1, 0x00,
            1, 1, 0x00,
            1, 1, 0xef,

            0, 4, 0x2b,
            1, 1, 0x00,
            1, 1, 0x00,
            1, 1, 0x00,
            1, 1, 0xef,

            0, 0, 0x2c,
        )

        # Screen area display parameters
        # Three elements in a tuple form a group, and each element in a single group is defined as follows:
        # 1: Type, 0 indicates command; 1 represents data; 2 indicates delay
        # 2: Length. If the type is 0, the length represents the amount of data after the command; If the type is 1, the length represents the length of the data
        # 3: Parameter value
        self.st7789v_invalid_data = (
            0, 4, 0x2a,
            1, 1, XSTART_H,
            1, 1, XSTART_L,
            1, 1, XEND_H,
            1, 1, XEND_L,
            0, 4, 0x2b,
            1, 1, YSTART_H,
            1, 1, YSTART_L,
            1, 1, YEND_H,
            1, 1, YEND_L,
            0, 0, 0x2c,
        )
        # lcd.lcd_ Init function parameter description
        # lcd_ init_ Data: incoming LCD configuration command
        # lcd_ Width: the width of the LCD screen. Width not exceeding 500
        # lcd_ High: the height of the LCD screen. Height not exceeding 500
        # lcd_ CLK: LCD SPI clock. SPI clock is 6.5k/13k/26k/52k
        # data_ Line: number of data lines. The parameter values are 1 and 2.
        # line_ Num: number of lines. The parameter values are 3 and 4.
        # lcd_ Type: screen type. 0：rgb； 1：fstn。
        # lcd_ Invalid: pass in the configuration command of LCD locale
        # lcd_ display_ On: pass in the configuration command of LCD screen
        # lcd_ display_ Off: pass in the configuration command of LCD screen off
        # lcd_ set_ Brightness: pass in the configuration command of LCD screen brightness. Set to none to indicate by LCD_ BL_ K controls the brightness (some screens are controlled by registers, and some are controlled by lcd_bl_k)
        ret = self.lcd.lcd_init(bytearray(self.st7789v_init_data), self.lcd_w, self.lcd_h, 6500, 1, 4, 0, bytearray(self.st7789v_invalid_data), None, None, None)
        self.lcdlog.info('lcd.lcd_init ret = {}'.format(ret))
        # Clear the screen and set it to white
        # self.lcd.lcd_clear(0xFFFF)

    def lcd_show_clear(self, colour):
        self.lcd.lcd_clear(colour)

	# Single character display
    # x - The X-axis shows the starting point
    # y - The Y-axis shows the starting point
    # xsize - font width
    # ysize - font height
    # ch_buf - stores the font data of the characters to be displayed
    # fc - font color，RGB565
    # bc - background color，RGB565
    def lcd_show_char(self, x, y, xsize, ysize, ch_buf, fc, bc):
        rgb_buf = []
        t1 = xsize // 8
        t2 = xsize % 8
        if t2 != 0:
            xsize = (t1 + 1) * 8
        for i in range(0, len(ch_buf)):
            for j in range(0, 8):
                if (ch_buf[i] << j) & 0x80 == 0x00:
                    rgb_buf.append(bc & 0xff)
                    rgb_buf.append(bc >> 8)
                else:
                    rgb_buf.append(fc & 0xff)
                    rgb_buf.append(fc >> 8)
        # If the screen character display fails, uncomment the next sentence and print the sent data using the for loop in the comment.
        # utime.sleep_ms(50)
        # for i in range(0, len(rgb_buf)):
        #     print("0x{:02x}".format(rgb_buf[i]))
        self.lcd.lcd_write(bytearray(rgb_buf), x, y, x + xsize - 1, y + ysize - 1)

    # ASCII character display, currently supports 8x16, 16x24 font size
    # If you need another font size, you need to add the corresponding font size to the library data, and add the corresponding font dictionary in the following function.
    # x - The X-axis shows the starting point
    # y - The Y-axis shows the starting point
    # xsize - font width
    # ysize - font height
    # ch - ASCII characters to be displayed
    # fc - font color，RGB565
    # bc - background color，RGB565
    def lcd_show_ascii(self, x, y, xsize, ysize, ch, fc, bc):
        ascii_dict = {}
        if xsize == 8 and ysize == 16:
            ascii_dict = fonts.ascii_8x16_dict
        elif xsize == 16 and ysize == 24:
            ascii_dict = fonts.ascii_16x24_dict

        for key in ascii_dict:
            if ch == key:
                self.lcd_show_char(x, y, xsize, ysize, ascii_dict[key], fc, bc)

    # Display string, currently supports 8x16 font size，
    # If you need another font size, you need to add the corresponding font size to the library data, and add the corresponding font dictionary in the lcd_show_ASCII function.
    # x - The X-axis shows the starting point
    # y - The Y-axis shows the starting point
    # xsize - font width
    # ysize - font height
    # ch - ASCII characters to be displayed
    # fc - font color，RGB565
    # bc - background color，RGB565
    def lcd_show_ascii_str(self, x, y, xsize, ysize, str_ascii, fc, bc):
        xs = x
        ys = y
        if (len(str_ascii) * xsize + x) > self.lcd_w:
            raise Exception('Display out of range')
        for ch in str_ascii:
            self.lcd_show_ascii(xs, ys, xsize, ysize, ch, fc, bc)
            xs += xsize

    # image shows
    # If the width and height of the picture is less than 80x80, this function can be directly written and displayed at one time
    # image_data - Store RGB data of pictures to be displayed
    # x - The X-axis shows the starting point
    # y - The Y-axis shows the starting point
    # width - param width
    # heigth - param height
    def lcd_show_image(self, image_data, x, y, width, heigth):
        self.lcd.lcd_write(bytearray(image_data), x, y, x + width - 1, y + heigth - 1)

    # image shows
    # If the width of the picture is larger than 80x80, use this function to display the piecewise writing. The principle of piecewise writing is as follows:
    # Take the width of the picture to be displayed as a fixed value, divide the picture to be displayed into several pictures with width * h in height, and calculate the actual height of the last piece less than H.
    # H is the height of each image after segmentation, which can be specified by the user through parameter H. The value of H should meet the relationship： width * h * 2 < 4096
    # path -TXT file path for storing image data, including file name, such as '/usr/image.txt.py'
    # x - The X-axis shows the starting point
    # y - The Y-axis shows the starting point
    # width - param width
    # heigth - param height
    # h - The height of each image after segmentation
    def lcd_show_image_file(self, path, x, y, width, heigth, h):
        image_data = []
        read_n = 0  # Number of bytes that have been read
        byte_n = 0  # number of bytes
        xs = x
        ys = y
        h_step = h
        h1 = heigth // h_step
        h2 = heigth % h_step
        # print('h1 = {}, h2 = {}'.format(h1, h2))
        with open(path, "r", encoding='utf-8') as fd:
            # for line in fd.readlines():
            end = ''
            while not end:
                line = fd.readline()
                if line == '':
                    end = 1
                else:
                    curline = line.strip('\r\n').strip(',').split(',')
                    for i in curline:
                        byte_n += 1
                        read_n += 1
                        image_data.append(int(i))
                        if h1 > 0 and byte_n == width * h_step * 2:
                            self.lcd_show_image(image_data, xs, ys, width, h_step)
                            image_data = []
                            ys = ys + h_step
                            h1 -= 1
                            byte_n = 0
                            # print('image_data len = {}'.format(len(image_data)))
                        elif h1 == 0 and read_n == width * heigth * 2:
                            if h2 != 0:
                                self.lcd_show_image(image_data, xs, ys, width, h2)

    # Convert 24 bit color to 16 bit color
    # If the 24-bit color of red is 0xFF0000, then r=0xFF,g=0x00,b=0x00,
    # Pass the values of r, g, and b into the following function to get 16-bit data of the same color
    @staticmethod
    def get_rgb565_color(r, g, b):
        return ((r << 8) & 0xF800) | ((g << 3) & 0x07E0) | ((b >> 3) & 0x001F)
