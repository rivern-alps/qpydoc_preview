# -*- coding: UTF-8 -*-
import utime
import checkNet
from usr import st7789v
from usr import image

# Common color definitions
red = 0xF800            # gules
green = 0x07E0          # green
blue = 0x001F           # blue
white = 0xFFFF          # white
black = 0x0000          # black
purple = 0xF81F         # purple
colour = white          # Default background color

# The following two global variables are mandatory, and users can modify the values of the following two global variables according to their actual projects.
# The values of these two variables are printed before the user code is executed.
PROJECT_NAME = "QuecPython_ST7789V_LCD_Example"
PROJECT_VERSION = "1.0.0"

checknet = checkNet.CheckNetwork(PROJECT_NAME, PROJECT_VERSION)
lcd_st7789v = st7789v.ST7789V(240, 240)


if __name__ == '__main__':
    # When running this routine manually, the delay can be removed. If the routine file name is changed to main.py and the startup is expected to run automatically, the delay needs to be added.
    # Otherwise, the information printed in poweron_print_once() below cannot be seen from the CDC port
    # utime.sleep(5)
    checknet.poweron_print_once()

    # If the user program contains network related code, you must execute wait_network_connected() to wait for the network to be ready (the dialing succeeded);
    # If it is network irrelevant code, you can mask it wait_network_connected()
    # checknet.wait_network_connected()

    # ################################################【User code star】################################################

    fc = 0x0000  # The font color black can be modified as required
    bc = 0xffff  # Background color white can be modified as required

    while True:
        # Thumbnails
        # The image to be displayed is 80*80 pixels, and the starting coordinate position of the image to be displayed is set as (80, 80).
        # Note that when displaying images, the last two parameters are passed in the image size, i.e. width and height, not the end
        lcd_st7789v.lcd_show_image(image.image_buf, 80, 80, 80, 80)

        # 16x24 ASCII
        lcd_st7789v.lcd_show_ascii(10, 10, 16, 24, 'Q', fc, bc)
        lcd_st7789v.lcd_show_ascii(26, 10, 16, 24, 'u', fc, bc)
        lcd_st7789v.lcd_show_ascii(42, 10, 16, 24, 'e', fc, bc)
        lcd_st7789v.lcd_show_ascii(58, 10, 16, 24, 'c', fc, bc)
        lcd_st7789v.lcd_show_ascii(74, 10, 16, 24, 't', fc, bc)
        lcd_st7789v.lcd_show_ascii(90, 10, 16, 24, 'e', fc, bc)
        lcd_st7789v.lcd_show_ascii(106, 10, 16, 24, 'l', fc, bc)
        # 8x16 ASCII
        lcd_st7789v.lcd_show_ascii(10, 40, 8, 16, 'Q', fc, bc)
        lcd_st7789v.lcd_show_ascii(18, 40, 8, 16, 'u', fc, bc)
        lcd_st7789v.lcd_show_ascii(26, 40, 8, 16, 'e', fc, bc)
        lcd_st7789v.lcd_show_ascii(34, 40, 8, 16, 'c', fc, bc)
        lcd_st7789v.lcd_show_ascii(42, 40, 8, 16, 'P', fc, bc)
        lcd_st7789v.lcd_show_ascii(50, 40, 8, 16, 'y', fc, bc)
        lcd_st7789v.lcd_show_ascii(58, 40, 8, 16, 't', fc, bc)
        lcd_st7789v.lcd_show_ascii(66, 40, 8, 16, 'h', fc, bc)
        lcd_st7789v.lcd_show_ascii(74, 40, 8, 16, 'o', fc, bc)
        lcd_st7789v.lcd_show_ascii(82, 40, 8, 16, 'n', fc, bc)

        utime.sleep(3)

        # Large picture display, note: large picture display time is longer. If the memory of the module is limited, do not download the image. TXT file and comment the following command.
        # lcd_st7789v.lcd_show_image_file('usr/image.txt', 0, 0, 240, 240, 1)
        lcd_st7789v.lcd_show_clear(0xFFFF)

    # ################################################【User code end 】################################################
