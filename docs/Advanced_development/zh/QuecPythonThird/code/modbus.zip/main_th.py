from usr.sensor import ModbusInit
import usr.uModBusConst as Const
from machine import UART
import utime as time

# 温湿度
uart_port = UART.UART0
bardrate = 9600
databits = 8
parity = 0
stopbit = 1
flowctl = 0

# 传感器addr信息
slave = 0x01
const = Const.READ_HOLDING_REGISTERS
start_addr = 0X00
coil_qyt = 0x02

def temp_humid_data_transfer(ret_str):
    str_list = list(map(lambda x: x.decode("utf-8"), ret_str.split(b",")))
    data_bits = int(str_list[2])
    data_list = str_list[3: 3 + data_bits]
    temp = int("0x" + data_list[0] + data_list[1], 16)
    humid = int("0x" + data_list[2] + data_list[3], 16)
    return temp/10.0, humid/10.0



if __name__ == '__main__':
    modbus = ModbusInit(uart_port, bardrate, databits, parity, stopbit, flowctl)
    while True:
        modbus.write_coils(slave, const, start_addr, coil_qyt)
        ret_str = modbus.read_uart()
        print(ret_str)
        temp, humid = temp_humid_data_transfer(ret_str)
        print(temp)
        print(humid)
        time.sleep_ms(1000)