

from usr.sensor import ModbusInit
import usr.uModBusConst as Const
from machine import UART
import utime as time


# 光照传感器
uart_port = UART.UART0
bardrate = 9600
databits = 8
parity = 0
stopbit = 1
flowctl = 0

# 传感器addr信息
slave = 0x01
const = Const.READ_HOLDING_REGISTERS
start_addr = 0X03
coil_qyt = 0x02


def light_data_transfer(ret_str):
    str_list = list(map(lambda x: x.decode("utf-8"), ret_str.split(b",")))
    data_bits = int(str_list[2])
    data_list = str_list[3: 3+data_bits]
    one_place = int("0x" + data_list[0] + data_list[1], 16)
    tens_place = int("0x" + data_list[2] + data_list[3], 16)
    return tens_place * 10 + one_place


if __name__ == '__main__':
    modbus = ModbusInit(uart_port, bardrate, databits, parity, stopbit, flowctl)
    while True:
        modbus.write_coils(slave, const, start_addr, coil_qyt)
        ret_str = modbus.read_uart()
        print(ret_str)
        digit_val = light_data_transfer(ret_str)
        print(digit_val)
        time.sleep_ms(1000)


